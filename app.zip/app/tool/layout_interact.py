import asyncio

from app.tool import BaseTool

# !/usr/bin/env python3
# network_sender.py - Python网络信号发送端

import socket
import time
import sys
import threading
from datetime import datetime
from app.logger import logger

class NetworkSender:
    def __init__(self, host='localhost', port=8888):
        self.host = host
        self.port = port
        self.socket = None
        self.connected = False

    def connect(self):
        """连接到服务器"""
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((self.host, self.port))
            self.connected = True
            print(f"Successfully connected to {self.host}:{self.port}")
            return True
        except Exception as e:
            print(f"Failed to connect to {self.host}:{self.port} - {e}")
            return False

    def disconnect(self):
        """断开连接"""
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
            self.connected = False
            print("Disconnected from server")

    def send_message(self, message):
        """发送消息"""
        if not self.connected:
            print("Not connected to server")
            return False

        try:
            # 发送消息
            self.socket.send(message.encode('utf-8'))

            # 接收回显 - 使用多种解码方式
            #response_bytes = self.socket.recv(1024)

            # 接收回显 - 增加缓冲区大小并支持分块接收
            response_bytes = b''
            chunk_size = 4096  # 增加到4KB
            
            # 设置socket超时以避免无限等待
            self.socket.settimeout(5.0)
            
            try:
                while True:
                    chunk = self.socket.recv(chunk_size)
                    if not chunk:
                        break
                    response_bytes += chunk
                    
                    # 如果数据量较小或者收到了完整的响应，可以提前结束
                    # 这里简单处理：如果连续收到的数据小于chunk_size，认为传输完成
                    if len(chunk) < chunk_size:
                        break
            except (socket.timeout, socket.error):
                # 超时是正常的，表示数据接收完毕
                pass
            finally:
                # 重置socket为阻塞模式
                self.socket.settimeout(None)


            # 尝试多种编码方式解码
            response = self.decode_response(response_bytes)
            print(f"Server response: {response}")
            return True
        except Exception as e:
            print(f"Error sending message: {e}")
            self.connected = False
            return False

    def decode_response(self, response_bytes):
        """安全解码服务器响应"""
        if not response_bytes:
            return ""

        # 显示原始字节信息用于调试
        hex_preview = response_bytes[:20].hex()
        print(f"  [DEBUG] Received {len(response_bytes)} bytes: {hex_preview}...")

        # 解码十六进制预览为可读文本
        try:
            preview_text = response_bytes[:20].decode('utf-8', errors='ignore')
            print(f"  [DEBUG] Hex preview as text: '{preview_text}...'")
        except:
            pass

        # 显示完整的十六进制内容（如果数据不长）
        if len(response_bytes) <= 50:
            full_hex = response_bytes.hex()
            print(f"  [DEBUG] Full hex: {full_hex}")
            # 将十六进制转换为可读文本显示
            try:
                full_text = bytes.fromhex(full_hex).decode('utf-8', errors='ignore')
                print(f"  [DEBUG] Full hex as text: '{full_text}'")
            except:
                pass

        # 尝试多种编码方式
        encodings = ['utf-8', 'gbk', 'gb2312', 'latin1', 'cp1252', 'ascii']

        for encoding in encodings:
            try:
                decoded = response_bytes.decode(encoding)
                print(f"  [DEBUG] Successfully decoded with {encoding}: '{decoded}'")
                return decoded
            except UnicodeDecodeError as e:
                print(f"  [DEBUG] Failed to decode with {encoding}: {e}")
                continue

        # 如果所有编码都失败，使用忽略错误的方式
        try:
            result = response_bytes.decode('utf-8', errors='ignore')
            print(f"  [DEBUG] Using UTF-8 with ignore errors: '{result}'")
            return result
        except:
            # 最后的备选方案：显示原始字节
            hex_str = response_bytes.hex()
            print(f"  [DEBUG] All decoding failed, showing raw bytes")
            return f"[Raw bytes: {hex_str}]"

    def hex_to_text(self, hex_string):
        """将十六进制字符串转换为文本"""
        try:
            # 移除可能的空格和换行
            hex_clean = hex_string.replace(' ', '').replace('\n', '').replace('\r', '')
            # 转换为字节然后解码
            bytes_data = bytes.fromhex(hex_clean)
            return bytes_data.decode('utf-8', errors='ignore')
        except Exception as e:
            return f"Hex decode error: {e}"

    def send_file(self, filename):
        """发送文件内容"""
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
                print(f"Sending file: {filename}")
                return self.send_message(f"FILE:{filename}\n{content}")
        except Exception as e:
            print(f"Error reading file {filename}: {e}")
            return False

    def interactive_mode(self):
        """交互模式"""
        print("\n=== Interactive Mode ===")
        print("Type messages to send to server")
        print("Special commands:")
        print("  /file <filename> - Send file content")
        print("  /auto - Start auto-sending test messages")
        print("  /test - Run simple test")
        print("  /hex <hex_string> - Decode hex string to text")
        print("  /quit - Quit")
        print("=" * 25)

        while self.connected:
            try:
                message = input("Enter message: ").strip()

                if not message:
                    continue

                if message == '/quit':
                    self.send_message("quit")
                    break
                elif message.startswith('/file '):
                    filename = message[6:].strip()
                    if filename:
                        self.send_file(filename)
                elif message == '/auto':
                    self.auto_send_mode()
                elif message == '/test':
                    self.simple_test()
                elif message.startswith('/hex '):
                    hex_string = message[5:].strip()
                    if hex_string:
                        decoded_text = self.hex_to_text(hex_string)
                        print(f"Decoded text: '{decoded_text}'")
                    else:
                        print("Please provide hex string. Example: /hex 48656c6c6f")
                else:
                    self.send_message(message)

            except KeyboardInterrupt:
                print("\nKeyboard interrupt received")
                break
            except Exception as e:
                print(f"Error in interactive mode: {e}")
                break

    def auto_send_mode(self):
        """自动发送模式"""
        print("\n=== Auto Send Mode ===")
        print("Sending test messages automatically...")
        print("Press Ctrl+C to stop auto sending")

        messages = [
            "Hello from Python sender!",
            "This is a test message",
            "Testing network communication",
            "Auto-generated message",
            "Python to C communication test"
        ]

        try:
            counter = 1
            while self.connected:
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                message = f"[{counter}] {timestamp} - {messages[counter % len(messages)]}"

                if not self.send_message(message):
                    break

                counter += 1
                time.sleep(2)  # 每2秒发送一次

        except KeyboardInterrupt:
            print("\nAuto sending stopped")

    def simple_test(self):
        """简单测试模式"""
        print("\n=== Simple Test Mode ===")
        test_messages = [
            "hello",
            "test",
            "123",
            "simple message",
            "quit"
        ]

        for i, msg in enumerate(test_messages):
            print(f"\n[Test {i + 1}] Sending: '{msg}'")
            if not self.send_message(msg):
                print("Failed to send message, stopping test")
                break
            time.sleep(1)  # 等待1秒


_NETWORK_SEND_DESCRIPTION = """
Send a text message to a remote server via TCP.
This tool connects to a specified host and port, sends a UTF-8 encoded message, waits for the server's echo response, and then disconnects.
Useful for triggering actions in local agents, services, or embedded systems.
"""



class layoutsend(BaseTool):
    name: str = "layoutsend"
    description: str = _NETWORK_SEND_DESCRIPTION
    parameters: dict = {
        "type": "object",
        "properties": {
            "message": {
                "type": "string",
                "description": "(required) The message content to send to the server. Can be plain text, command, or structured data like JSON."
            },
            "host": {
                "type": "string",
                "description": "(optional) Target server hostname or IP address. Default: localhost",
                "default": "localhost"
            },
            "port": {
                "type": "integer",
                "description": "(optional) Target server port number. Default: 8888",
                "default": 8888
            }
        },
        "required": ["message"]
    }

    async def execute(
        self,
        message: str,
        host: str = "localhost",
        port: int = 8888
    ) -> str:
        """
        Send a message to a remote server via TCP.

        Args:
            message: The message to send (generated by the LLM)
            host: Server address (default: localhost)
            port: Server port (default: 8888)

        Returns:
            Human-readable result indicating success or failure
        """
        logger.info(f"[network_send] Sending message to {host}:{port}")

        sender = NetworkSender(host=host, port=port)

        # Step 1: Connect
        if not sender.connect():
            return f"❌ Failed to connect to {host}:{port}"

        try:
            # Step 2: Send message
            success = sender.send_message(message)
            if success:
                return f"✅ Message sent successfully to {host}:{port}\nMessage: {message}"
            else:
                return f"❌ Failed to send message to {host}:{port}"
        except Exception as e:
            logger.exception(f"[network_send] Unexpected error: {e}")
            return f"❌ Error during communication: {str(e)}"
        finally:
            # Step 3: Always disconnect
            sender.disconnect()

async def simple_mode():
    """模拟 simple_test() 行为：发送固定测试消息序列"""
    tool = layoutsend()
    host = "localhost"
    port = 8888

    # 模拟 simple_test 中的消息序列
    test_messages = [
        "hello",
        "test",
        "123",
        "polygon layer=mos2;points=0 0;200 0;400 0;600 0;800 0;1000 0;1000 200;1000 400;1000 600;1000 800;1000 1000;800 1000;600 1000;400 1000;200 1000;0 1000",
        "quit"
    ]

    print("🧪 模拟 '简单测试模式' (simple_test)")
    print(f"目标地址: {host}:{port}")
    print("-" * 50)

    for i, msg in enumerate(test_messages, 1):
        print(f"\n📤 [{i}/{len(test_messages)}] 发送消息: '{msg}'")
        result = await tool.execute(
            message=msg,
            host=host,
            port=port
        )
        print(f"✅ 结果: {result}")

        # 小延迟，模拟人类操作
        await asyncio.sleep(1.0)

    print("\n✅ 所有测试消息发送完成。")


if __name__ == "__main__":
    asyncio.run(simple_mode())